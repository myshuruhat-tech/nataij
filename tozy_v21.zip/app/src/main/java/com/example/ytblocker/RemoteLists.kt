package com.example.ytblocker

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// Fetches block lists from the relay (updated by the admin app's screen) and caches the latest copy
object RemoteLists {
    // Not private because UsageReport uses them for the same relay/pairing code
    const val URL_BASE = "https://nataij-api.myshuruhat.workers.dev"
    const val PAIR = "xeb3vuyM0FOa"

    class Data(
        val handles: List<String>, val names: List<String>, val exact: List<String>, val blocking: Boolean,
        val fullBlockApps: List<String> = emptyList(), val scanApps: List<String> = emptyList(),
        val searchApps: List<String> = emptyList(), val warningMessage: String = "",
        val logApps: List<String> = emptyList()
    )

    private fun p(ctx: Context) = ctx.getSharedPreferences("remote", Context.MODE_PRIVATE)

    fun load(ctx: Context): Data? {
        val raw = p(ctx).getString("data", null) ?: return null
        return try {
            val o = JSONObject(raw)
            fun l(k: String): List<String> { val a = o.optJSONArray(k) ?: return emptyList(); return (0 until a.length()).map { a.getString(it) } }
            Data(l("handles"), l("names"), l("exact"), o.optBoolean("blocking", true), l("fullBlockApps"), l("scanApps"), l("searchApps"), o.optString("warningMessage", ""), l("logApps"))
        } catch (e: Exception) { null }
    }

    fun pull(ctx0: Context, onChanged: () -> Unit) {
        val ctx = ctx0.applicationContext
        Thread {
            try {
                val c = URL("$URL_BASE/blocklist?pair=$PAIR&device=${DeviceSync.deviceId(ctx)}").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode !in 200..299) return@Thread
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                val o = JSONObject(txt)
                if (o.optBoolean("empty", false)) return@Thread // Admin hasn't sent anything yet: keep using the built-in lists
                if (txt == p(ctx).getString("data", null)) return@Thread
                p(ctx).edit().putString("data", txt).apply()
                onChanged()
            } catch (e: Exception) { }
        }.start()
    }
}
